<?php
 $connect = mysqli_connect("localhost", "root", "", "francis");  
 $query= "SELECT * FROM contact";
 $result=mysqli_query($connect,$query);
?>
<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width" />
      <title>FRANCIS</title>
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/responsee.css">
      <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="owl-carousel/owl.theme.css">

      
    <!-- Favicons
    ================================================== -->
    <link rel="stylesheet" href="img/Logo.jpg" type="image/x-icon">
    <link rel="stylesheet" href="img/apple-touch-icon.jpg">
    <link rel="stylesheet =" href="img/Logo.jpg">
    <link rel="stylesheet" sizes="114x114" href="img/Logo.jpg">
      <!-- CUSTOM STYLE -->
      <link rel="stylesheet" href="css/template-style.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
      <script type="text/javascript" src="js/modernizr.js"></script>
      <script type="text/javascript" src="js/responsee.js"></script>
      <script type="text/javascript" src="js/template-scripts.js"></script> 
                 
      <!--[if lt IE 9]>
	      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
      <![endif]-->
   </head>
   <body class="size-1140">
      <!-- TOP NAV WITH LOGO -->
      <header>
        
         <nav>
            <div class="line">
               <div class="s-12 l-2">
                <p style="color: beige;"> FRANCIS</p>
               </div>
               <div class="top-nav s-12 l-10">
                  <p class="nav-text">Custom menu text</p>
                  <ul class="right">
                     <li><a href="index.php">Home</a></li>
                     <li><a href="projects.php">Projects</a></li>
                     <li><a href="skills.php">Skills</a></li>                                  
                     <li class="active-item"><a href="#">Contact</a></li>
                  </ul>
               </div>
            </div>
         </nav>
      </header>  
      <section>
        
         <!-- CONTACT --> 
         <div id="contact">
            <div class="line">
               <h2 class="section-title">Contact Us</h2>
               <div class="margin">
                  <div class="s-12 m-12 l-3 hide-m hide-s margin-bottom right-align">
                    <img src="img/Logo1.jpg" alt="">
                  </div>
                  <div class="s-12 m-12 l-4 margin-bottom right-align">
                  <h3 style="margin-left:-120px;">contact details</h3>
                     <table style="background-color:#e0e0d1; text-align:left; margin-left:-120px;  width:900px;  ">
                <thead>
                <tr style="background-color:#e0e0d1; text-align:left;  width:150px;  ">
                    <th>CONTACT ID</th>
                  
                    <th>CONTACT NAME</th>
                    <th>CONTACT LOCATION</th>
                    <th>EMAIL</th>
                </tr>
                <?php 
                       while($rows= mysqlI_fetch_assoc($result))
              {
              ?>
              <tr>
                    <td><?php echo $rows['id']; ?></td>     
                    <td><?php echo $rows['contact_name']; ?></td>
                    <td><?php echo $rows['contact_location']; ?></td>   
                    <td><?php echo $rows['email']; ?></td>
              
                    

              </tr>
              <?php }?>
     
                   

             
            </thead>
        </table>

                  </div>
      </section>
      <!-- FOOTER -->
      <footer>
         <div class="line">
            <div class="s-12 l-6">
               <p>Copyright 2022, francis</p>
              
            </div>
        
         </div>
      </footer>
      <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>
      <script type="text/javascript">
         jQuery(document).ready(function($) {
            var theme_slider = $("#owl-demo");
            $("#owl-demo").owlCarousel({
                navigation: false,
                slideSpeed: 300,
                paginationSpeed: 400,
                autoPlay: 6000,
                addClassActive: true,
             // transitionStyle: "fade",
                singleItem: true
            });
            $("#owl-demo2").owlCarousel({
                slideSpeed: 300,
                autoPlay: true,
                navigation: true,
                navigationText: ["&#xf007","&#xf006"],
                pagination: false,
                singleItem: true
            });
        
            // Custom Navigation Events
            $(".next-arrow").click(function() {
                theme_slider.trigger('owl.next');
            })
            $(".prev-arrow").click(function() {
                theme_slider.trigger('owl.prev');
            })     
        }); 
      </script>
   </body>
</html>