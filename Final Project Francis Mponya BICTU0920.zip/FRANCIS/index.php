<?php
 $connect = mysqli_connect("localhost", "root", "", "francis");  
?>
<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width" />
      <title>FRANCIS</title>
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/responsee.css">
      <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="owl-carousel/owl.theme.css">

      
    <!-- Favicons
    ================================================== -->
    <link rel="stylesheet" href="img/Logo.jpg" type="image/x-icon">
    <link rel="stylesheet" href="img/apple-touch-icon.jpg">
    <link rel="stylesheet =" href="img/Logo.jpg">
    <link rel="stylesheet" sizes="114x114" href="img/Logo.jpg">
      <!-- CUSTOM STYLE -->
      <link rel="stylesheet" href="css/template-style.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
      <script type="text/javascript" src="js/modernizr.js"></script>
      <script type="text/javascript" src="js/responsee.js"></script>
      <script type="text/javascript" src="js/template-scripts.js"></script> 
                 
      <!--[if lt IE 9]>
	      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
      <![endif]-->
   </head>
   <body class="size-1140">
      <!-- TOP NAV WITH LOGO -->
      <header>
        
         <nav>
            <div class="line">
               <div class="s-12 l-2">
                <p style="color: beige;"> FRANCIS MPONYA</p>
               </div>
               <div class="top-nav s-12 l-10">
                  <p class="nav-text">Custom menu text</p>
                  <ul class="right">
                     <li class="active-item"><a href="#carousel">Home</a></li>
                     <li><a href="projects.php">Projects</a></li>
                     <li><a href="skills.php">Skills</a></li>                                  
                     <li><a href="contact.php">Contact</a></li>
                  </ul>
               </div>
            </div>
         </nav>
      </header>  
      <section>
         <!-- CAROUSEL --> 
         <div id="carousel">
            <div id="owl-demo" class="owl-carousel owl-theme"> 
               <div class="item">
                  <img src="img/fra.jpg" alt="" style="width: 1400px ; height:800px;">
                  <div class="line"> 
                     <div class="text hide-s" style="margin-top: 170px;">
                        <div class="line"> 
                          <div class="prev-arrow hide-s hide-m">
                             <i class="icon-chevron_left"></i>
                          </div>
                          <div class="next-arrow hide-s hide-m">
                             <i class="icon-chevron_right"></i>
                          </div>
                        </div> 
                        <h2>Introduction </h2>
                        <p> I am Francis Mponya, from Nsanje currently staying Mzuzu City </br>
                           I pursued my secondary school education at Balaka Secondary School.</p>
                     </div>
                  </div>
               </div>
               <div class="item">
                  <img src="img/tele.jpg" alt="" style="width: 1400px ; height:600px;  margin-top: 75px;">
                  <div class="line">
                     <div class="text hide-s" style="margin-top: 170px;"> 
                        <div class="line"> 
                          <div class="prev-arrow hide-s hide-m">
                             <i class="icon-chevron_left"></i>
                          </div>
                          <div class="next-arrow hide-s hide-m">
                             <i class="icon-chevron_right"></i>
                          </div>
                        </div> 
                        <h2>GOAL </h2>
                        <p>I did a diploma in Telecommunications
                           at the Malawi University of Applied Sciences(MUBAS). </p>
                     </div>
                  </div>
               </div>
               <div class="item">
                  <img src="img/mzuni.jpg" alt="" style="width: 1400px ; height:600px; margin-top: 105px;">
                  <div class="line">
                     <div class="text hide-s" style="margin-top: 170px;">
                        <div class="line"> 
                          <div class="prev-arrow hide-s hide-m">
                             <i class="icon-chevron_left"></i>
                          </div>
                          <div class="next-arrow hide-s hide-m">
                             <i class="icon-chevron_right"></i>
                          </div>
                        </div> 
                        <h2>CURRENT GOAL</h2>
                        <p>Currently am at Mzuzu University(MZUNI) pursueing a degree in ICT.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- FIRST BLOCK -->
         <div id="first-block">
            <div class="line">
               <h1>Contact Form </h1>
               <div class="s-12 m-12 l-5 center">
                  <form class="customform" action="">
                     <div class="s-12"><input name="" placeholder="Your e-mail" title="Your e-mail" type="email" /></div>
                     <div class="s-12"><input name="" placeholder="Your name" title="Your name" type="text" /></div>
                     <div class="s-12"><textarea placeholder="Your message" name="" rows="5"></textarea></div>
                     <div class="s-12 m-12 l-4"><button class="color-btn" type="submit">Submit Button</button></div>
                   </form>
               </div>
            </div>
         </div>
         
      </section>
      <!-- FOOTER -->
      <footer>
         <div class="line">
            <div class="s-12 l-6">
               <p>Copyright 2022, francis</p>
             
          
         </div>
      </footer>
      <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>
      <script type="text/javascript">
         jQuery(document).ready(function($) {
            var theme_slider = $("#owl-demo");
            $("#owl-demo").owlCarousel({
                navigation: false,
                slideSpeed: 300,
                paginationSpeed: 400,
                autoPlay: 6000,
                addClassActive: true,
             // transitionStyle: "fade",
                singleItem: true
            });
            $("#owl-demo2").owlCarousel({
                slideSpeed: 300,
                autoPlay: true,
                navigation: true,
                navigationText: ["&#xf007","&#xf006"],
                pagination: false,
                singleItem: true
            });
        
            // Custom Navigation Events
            $(".next-arrow").click(function() {
                theme_slider.trigger('owl.next');
            })
            $(".prev-arrow").click(function() {
                theme_slider.trigger('owl.prev');
            })     
        }); 
      </script>
   </body>
</html>